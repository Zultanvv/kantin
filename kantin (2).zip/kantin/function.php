<?php

session_start();

//Bikin koneksi
$c = mysqli_connect('localhost', 'root', '', 'kantin');

//Login
if(isset($_POST['login'])){
    //Initiate variable
    $username = $_POST['username'];
    $password = $_POST['password'];

    $check = mysqli_query($c, "SELECT * FROM user WHERE username='$username' and password='$password'");
    $hitung = mysqli_num_rows($check);

    if($hitung>0){
        //Jika datanya ditemukan
        //berhasil login

        $_SESSION['login'] = 'True';
        header('location:index.php');
    } else{
        //Data tidak ditemukan
        //gagal login
        echo '
        <script>alern("Username atau Password salah");
        window.location.href="login.php"
        </script>
        ';

    }   
}


if(isset($_POST['tambahbarang'])){
    $namaproduk = $_POST['namaproduk'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];
    $harga = $_POST['harga'];

    $insert = mysqli_query($c, "insert into produk (namaproduk,deskripsi,harga,stok) values ('$namaproduk','$namaproduk','$harga','$stok')");


    if($insert){
        header('location:stock.php');
    } else {
        echo '
        <script>alert("Gagal menambah barang baru");
        window.location.href="stock.php"
        </script>
        ';
    }

}

?>